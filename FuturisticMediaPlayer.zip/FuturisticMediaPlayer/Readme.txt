Installation:
	
	Step 1:
Unzip the downloaded file. 

This will create 4 files. 
	1. Readme.text
	2.	FUTURISTICMediaPlayer.exe
	3.	MediaPlayer.htm
	4.	tipofday.txt

	Step 2:

	run FUTURISTICMediaPlayer.exe
This will prompt that you are using the software for the first time.





Solution to some known problems :
	1.VB runtimes should be present, i.e. VB runtimes 6.0.
	2.If by any reason you are unable to run the application (deleted some skin files or changed path etc) then just delete the file save.ata. This will reset the media player to default settings. (This file will be created again once you start the application)
