How to install?

Unzip the content of the zipped file (BollySnakesandLaddersSS.zip) to windows' directory (eg c:\windows). Windows directory should have :
1. BollySnakes&LaddersScreenSaver.scr 
2. Folder "sound" with sound files within it.
3. Readme.txt (This can be deleted).




How to Run?

Right click on the desktop and select "BollySnakes&LaddersScreenSaver" as the screen saver from screen saver tab.

Click "OK" to set it. Change the different settings using the settings option. 




What options are available?

1. Option to change the board pattern.
2. Change background color.
3. Enable/disable sound.
4. Change game type and other game options.
5. Allows you to cheat:
    a. You can make the player win the way you want.
    b. Change "Created by String" and assign it anything (eg your name).